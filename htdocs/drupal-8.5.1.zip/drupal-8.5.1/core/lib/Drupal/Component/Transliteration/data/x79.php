<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'jian', 'jiao', 'xi', 'zhang', 'qiao', 'dun', 'jian', 'yu', 'zhui', 'he', 'ke', 'ze', 'lei', 'ke', 'chu', 'ye',
  0x10 => 'que', 'dang', 'yi', 'jiang', 'pi', 'pi', 'yu', 'pin', 'e', 'ai', 'ke', 'jian', 'yu', 'ruan', 'meng', 'pao',
  0x20 => 'ci', 'bo', 'yang', 'ma', 'ca', 'xian', 'kuang', 'lei', 'lei', 'zhi', 'li', 'li', 'fan', 'que', 'pao', 'ying',
  0x30 => 'li', 'long', 'long', 'mo', 'bo', 'shuang', 'guan', 'lan', 'zan', 'yan', 'shi', 'shi', 'li', 'reng', 'she', 'yue',
  0x40 => 'si', 'qi', 'ta', 'ma', 'xie', 'yao', 'xian', 'qi', 'qi', 'zhi', 'beng', 'dui', 'zhong', 'ren', 'yi', 'shi',
  0x50 => 'you', 'zhi', 'tiao', 'fu', 'fu', 'mi', 'zu', 'zhi', 'suan', 'mei', 'zuo', 'qu', 'hu', 'zhu', 'shen', 'sui',
  0x60 => 'ci', 'chai', 'mi', 'lu', 'yu', 'xiang', 'wu', 'tiao', 'piao', 'zhu', 'gui', 'xia', 'zhi', 'ji', 'gao', 'zhen',
  0x70 => 'gao', 'shui', 'jin', 'shen', 'gai', 'kun', 'di', 'dao', 'huo', 'tao', 'qi', 'gu', 'guan', 'zui', 'ling', 'lu',
  0x80 => 'bing', 'jin', 'dao', 'zhi', 'lu', 'chan', 'bei', 'zhe', 'hui', 'you', 'xi', 'yin', 'zi', 'huo', 'zhen', 'fu',
  0x90 => 'yuan', 'wu', 'xian', 'yang', 'zhi', 'yi', 'mei', 'si', 'di', 'bei', 'zhuo', 'zhen', 'yong', 'ji', 'gao', 'tang',
  0xA0 => 'si', 'ma', 'ta', 'fu', 'xuan', 'qi', 'yu', 'xi', 'ji', 'si', 'chan', 'dan', 'gui', 'sui', 'li', 'nong',
  0xB0 => 'mi', 'dao', 'li', 'rang', 'yue', 'ti', 'zan', 'lei', 'rou', 'yu', 'yu', 'li', 'xie', 'qin', 'he', 'tu',
  0xC0 => 'xiu', 'si', 'ren', 'tu', 'zi', 'cha', 'gan', 'yi', 'xian', 'bing', 'nian', 'qiu', 'qiu', 'zhong', 'fen', 'hao',
  0xD0 => 'yun', 'ke', 'miao', 'zhi', 'jing', 'bi', 'zhi', 'yu', 'mi', 'ku', 'ban', 'pi', 'ni', 'li', 'you', 'zu',
  0xE0 => 'pi', 'bo', 'ling', 'mo', 'cheng', 'nian', 'qin', 'yang', 'zuo', 'zhi', 'zhi', 'shu', 'ju', 'zi', 'huo', 'ji',
  0xF0 => 'cheng', 'tong', 'zhi', 'huo', 'he', 'yin', 'zi', 'zhi', 'jie', 'ren', 'du', 'yi', 'zhu', 'hui', 'nong', 'fu',
];
